import { Alert } from 'react-native';

/**
 * Captura erros JavaScript não tratados. Em vez de o app fechar ("memorIA parou"),
 * mostra a mensagem na tela para o usuário poder tirar um print, e registra no logcat.
 */
type Handler = (error: unknown, isFatal?: boolean) => void;
const errorUtils = (globalThis as unknown as { ErrorUtils?: { setGlobalHandler(h: Handler): void } }).ErrorUtils;

let showing = false;

errorUtils?.setGlobalHandler((e, isFatal) => {
  const err = e instanceof Error ? e : new Error(String(e));
  console.error(`[memorIA] erro ${isFatal ? 'FATAL' : ''}: ${err.message}\n${err.stack ?? ''}`);
  if (showing) return;
  showing = true;
  const stack = (err.stack ?? '').split('\n').slice(0, 6).join('\n');
  Alert.alert(
    'O memorIA encontrou um erro',
    `${err.message}\n\n${stack}\n\nTire um print desta tela e envie para o suporte.`,
    [{ text: 'OK', onPress: () => (showing = false) }],
  );
});
