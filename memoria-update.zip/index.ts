// 1º: captura de erros (mostra na tela em vez de fechar o app).
import './src/crashGuard';
// As tarefas de background (geofencing e replanejamento de alertas) precisam ser
// definidas no escopo global, antes do app montar, para funcionar com o app fechado.
import './src/services/backgroundTasks';
import 'expo-router/entry';
