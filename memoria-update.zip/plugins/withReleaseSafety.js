/**
 * Config plugin: desliga o R8 (minify/shrink) no build de release.
 * O SDK 58 liga o R8 por padrão e ele pode remover/renomear classes nativas usadas por
 * reflexão em módulos de terceiros, derrubando o app na abertura. O APK fica um pouco
 * maior, mas muito mais seguro.
 */
const { withGradleProperties } = require('expo/config-plugins');

function setProp(props, key, value) {
  const existing = props.find((p) => p.type === 'property' && p.key === key);
  if (existing) existing.value = value;
  else props.push({ type: 'property', key, value });
}

module.exports = function withReleaseSafety(config) {
  return withGradleProperties(config, (cfg) => {
    setProp(cfg.modResults, 'android.enableMinifyInReleaseBuilds', 'false');
    setProp(cfg.modResults, 'android.enableShrinkResourcesInReleaseBuilds', 'false');
    return cfg;
  });
};
